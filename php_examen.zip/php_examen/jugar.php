<?php /** @noinspection PhpMultipleClassDeclarationsInspection */
require_once ('Juego.php');
//Identifica las variabbles que vas a necesitar
//Esta parte no es obligatoria pero te ayudará a hacer el programa

$idiomas = filter_input(INPUT_POST, "idiomas");
$nombre = filter_input(INPUT_POST, "nombre");
$intentos = filter_input(INPUT_POST, "num_intentos");
$opcion = $_POST['idiomas'] ?? null;
$opcionjuego = $_GET['botones'] ?? null;
$max = 1024;
$min = 11;

//case que hace que se carge la frase del idioma definida en index
switch ($opcion) {

    //tener en cuenta el hacer variables para cambiar toda la pagina de idioma
    case "esp":
        $nombre_idioma = "Español";
        $msj = " ESP - Opciones de aplicación para "."<b>".$nombre."</b>"." con idioma "."<b>".$nombre_idioma."</b>";
        break;

    case "eng":
        $nombre_idioma = "Inglés";
        $msj = " ENG - Opciones de aplicación para "."<b>".$nombre."</b>"." con idioma "."<b>".$nombre_idioma."</b>";
        break;

    case "fr":
        $nombre_idioma = "Francés";
        $msj = " FR - Opciones de aplicación para "."<b>".$nombre."</b>"." con idioma "."<b>".$nombre_idioma."</b>";
        break;

    case "jugar":
        Juego::jugar();
        break;

    case "reiniciar": header("location:jugar.php");//Acciones si he presionado volver
        break;

    case "volver": header("location:index.php");//Acciones si he presionado volver
        break;
}

?>


<!doctype html>
<html lang="es">
<head>
    <title></title>
</head>
<body style="width: 70%;float:left;margin-left: 20%; ">

<h3></h3>
<fieldset style="width:100%;background:bisque ">
    <legend></legend>
    <form action="index.php" method="POST" >
        <input type="submit" value="Borrar identificación y reiniciar juego" name="submit" >
        <input type="submit" value="Comenzar" name="comenzar" >
        <input type="hidden" value="<?= $idiomas ?>" name="idiomas">
        <hr />
    </form>
</fieldset>

<h3></h3>
<fieldset style="width:40%;background:bisque; hidden ">
    <legend>Empieza el juego</legend>
    <form action="jugar.php" method="POST" >
        <h2> El n&uacutemero es <?= $num = Juego::generar_valor() ?> ?</h2>
        <h5> Jugada <?= $jugada ?> </h5>
        <h5> Actualmente te quedan x intentos </h5>

        <input type="hidden" value="<?= $jugada ?>" name="num_intentos">
        <input type="hidden" value="<?= $num ?>" name="num">
        <input type="hidden" value="<?= $max ?>" name="max">
        <input type="hidden" value="<?= $min ?>" name="min">
        <input type="hidden" value="<?= $jugada ?>" name="jugada">

        <fieldset>

            <legend>Indica c&oacutemo es el n&uacutemero qu&eacute has pensado</legend>
            <label><input type="radio" name="rtdo" checked value='>'></label> Mayor<br />
            <label><input type="radio" name="rtdo" value='<'></label>Menor<br />
            <label><input type="radio" name="rtdo" value='='></label> Igual<br />

        </fieldset>
        <br />
        <form action="jugar.php" method="POST" name="botones">
        <input type="submit" value="jugar" name="submit">
        <input type="submit" value="reiniciar" name="submit">
        <input type="submit" value="volver" name="submit" >
    </form>
</fieldset>
</body>

</html>