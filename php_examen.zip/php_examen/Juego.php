<?php /** @noinspection PhpMultipleClassDeclarationsInspection */

//serializar valores ???
class Juego{

    private static int $jugada = 1;
    private static int $max = 1024;
    private static int $min = 0;
    private static int $num;


    static public function jugar(): int
    {//funcion que inicia el juego, usa el operador de resolucion de ambito
        self::obtener_valores();
        if (self::$jugada>10)
            self::finjuego("false");
        self::generar_valor($_POST['resultado']);
        //self::generar_valor($_POST['resultado']);
        return (self::$num);//devuelve numero
    }

    static function generar_valor($resultado){

        switch ($resultado){
            case">":
                self::$min = self::$num;
                break;

            case"<":
                self::$max = self::$num;
                break;

            case"=":
                self::finJuego("true");
                break;

        }
        self::$num = (self::$min+self::$max)/2;}

    static function obtener_valores(){
        self::$min = $_POST['min'];
        self::$max = $_POST['max'];
        self::$jugada = $_POST['jugada']++;
    }
    ///

}//INVOCAR Jugada::jugar();

//jugarphp recupero valores de la clase para los textos
//escribir en jugar.php
//$jugada::Jugada::getJugada();
//$num::Jugada::getnum();
//$max::JUgada::getmax();
//$min::Jugada::getmin();
//Enviar al index si entro a jugar php desde navegador