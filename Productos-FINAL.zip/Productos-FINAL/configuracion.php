
<?php

const HOST = "localhost";
const USER = "root";
const PASS = "password";
const BD = "dwes";

?>