<?php
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="CSS/estilo.css" type="text/css">
    <title>Document</title>
</head>
<body>
<div class="contenedor">
<h1>Lista de programas básico de pruebas</h1>
    <hr />
<h2><a href="variables.php">Variables en php</a></h2>
<h2><a href="constantes.php">Constantes en php</a></h2>
<h2><a href="asignacion.php">Asignación en php</a></h2>
<h2><a href="seleccion.php">Selección en php</a></h2>
<h2><a href="ternario.php">Operador Ternario en php</a></h2>
<h2><a href="iteraciones.php">Iteraciones en php</a></h2>
<h2><a href="funciones.php">Funciones </a></h2>
</div>
</body>
</html>
