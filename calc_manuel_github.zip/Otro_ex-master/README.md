#Calculadora
*Proyecto para hacer una calculadora a partir de una expresión
*Usado como ejemplo para programación orientada a objetos con php
