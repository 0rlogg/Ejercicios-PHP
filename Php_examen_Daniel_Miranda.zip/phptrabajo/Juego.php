<?php

class Juego{

    private static $jugada;
    private static $max;
    private static $min;
    private  static $num;

    static public function jugar(){//funcion que inicia el juego, usa el operador de resolucion de ambito
        self::obtener_valores();
        if (self::$jugada>10)
                self::fin_juego();
        self::generar_valor($_POST['resultado_jugada']);
        self::guardar_valores();
        return (self::$num);//devuelve numero
    }

    public function menor(){//Funcion para que el programa pueda adivinar el numero, si en este caso el usuario escogiera menor esta funcion Devuelve el cociente entero de la división
        $min=$this->num;
        $num = intdiv($min+$this->max, 2);
    }

    public function mayor(){//Funcion para que el programa pueda adivinar el numero, si en este caso el usuario escogiera mayor esta funcion Devuelve el cociente entero de la división
        $max=$this->num;
        $num = intdiv($this->min+$this->max, 2);
    }

    public function igual(){//Funcion igual, esta se usa para que el uusuario demuestre al programa que ha adivinado el numero. nos lleva a lapagina fin.php
        header ("Location:fin.php?jugada=$this->jugada");
    }

    public function obtener_valores(){//funcion de obtencion de valores

    }

    public function guardar_valores(){//funcion para guardar valores, en este caso no la necesitamos ya que el formulario los guarda


    }


}